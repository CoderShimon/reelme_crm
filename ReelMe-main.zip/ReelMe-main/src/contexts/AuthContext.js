import React, { useContext, useState, useEffect } from "react"
import { auth, db, storage } from "../firebase"
import firebase from "firebase/app"
const AuthContext = React.createContext()

export function useAuth() {
  return useContext(AuthContext)
}

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState()
  const [loading, setLoading] = useState(true)
  
  function signup(email, password) {
    return auth.createUserWithEmailAndPassword(email, password)
  }

  function login(email, password) {
    return auth.signInWithEmailAndPassword(email, password)
  }

  function logout() {
    return auth.signOut()
  }

  function addTopics(collection, id, docDictionary) {
    docDictionary.createdDate = firebase.firestore.Timestamp.fromDate(new Date())
    return db.collection(collection).doc(id).set(docDictionary)
  }

  function checkRecordExists(collection, id) {
    return db.collection(collection).doc(id).get()
  }

  function deleteUserPermanent(uid) {
    // Set the "capital" field of the city 'DC'
    db.collection("users").doc(uid).delete();
  }

  function resetPassword(email) {
    return auth.sendPasswordResetEmail(email)
  }

  function updateEmail(email) {
    return currentUser.updateEmail(email)
  }

  function updatePassword(password) {
    return currentUser.updatePassword(password)
  }

  function updateUserProfile(profile) {
    return currentUser.updateProfile(profile)
  }

  function collectionDetails(collection) {
    return db.collection(collection).get()
  }

  function updateCollectionDetails(collection, id, docDictionary) {
    return db.collection(collection).doc(id).update(docDictionary);
  }

  function getDateFromFirestore(date) {
    var year = date.getFullYear();
    var mes = date.getMonth()+1;
    var dia = date.getDate();
      return dia+"-"+mes+"-"+year
   }

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(user => {
      setCurrentUser(user)
      setLoading(false)
    })

    return unsubscribe
  }, [])

  const value = {
    storage,
    currentUser,
    login,
    signup,
    logout,
    resetPassword,
    updateEmail,
    updatePassword,
    collectionDetails,
    deleteUserPermanent,
    addTopics,
    updateCollectionDetails,
    getDateFromFirestore,
    updateUserProfile,
    checkRecordExists
  }

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  )
}