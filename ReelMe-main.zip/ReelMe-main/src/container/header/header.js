import React from "react"
import "./header.css";
import bell from "../../assets/Mask Group 448.png";
import header_profile from "../../assets/avtar.png";
import search_glass from "../../assets/Mask Group 446.png";
import { useAuth } from "../../contexts/AuthContext"


export default function Header() {
    const { currentUser } = useAuth()
    return ( 
        <div className="header w-100 ">
            <div className="row">
                <div className="col d-flex justify-content-between align-items-center pr-0">
                   <p className="header_head raleway_bold">ReelMe Administration Panel</p>
                   <img alt="" src={bell}  className="bell_icon"/>
                </div>
                <div className="col d-flex justify-content-between align-items-center">
                
                    <div className="header_profile_div">
                        <img alt="" src={currentUser.photoURL == undefined || currentUser.photoURL === null ? header_profile : currentUser.photoURL} className="header_profile" />
                        <p>{currentUser.displayName}</p>
                    </div>
                   
                    <input type="search" placeholder="Search here..." className="header_searchbar" />
                    <button type="submit" className="search_button"><img alt="" src={search_glass} className="search_glass-icon"/></button>
                </div>
            </div>
            
        </div>
     );
}