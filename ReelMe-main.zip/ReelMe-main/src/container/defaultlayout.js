import React,{Component} from "react";
import { Redirect, Route, Switch } from "react-router-dom";
import Header from "./header/header";
import Sidebar from "./sidebar/sidebar";
import routes from "../routes";

import "./defaultlayout.css";


class DefaultLayout extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( 

        <div className="app">
              <Sidebar/>
              <div className="w-100">
              <Header/>
                <div className="app-body">
                  <main className="main">
                    
                      <Switch>
                          {routes.map((route, idx) => {
                            return route.component ? (
                              <Route
                                key={idx}
                                path={route.path}
                                exact={route.exact}
                                name={route.name}
                                render={(props) => <route.component {...props} />}
                              />
                            ) : null;
                          })}
                          <Redirect from="/" to="/" />
                        </Switch>
                  
                  </main>    
                </div>
            </div>
          </div>
         );
    }
}
 
export default DefaultLayout;