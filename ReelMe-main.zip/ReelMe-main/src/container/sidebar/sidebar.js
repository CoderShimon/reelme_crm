import React, {  useState } from "react"
import "./sidebar.css";
import { NavLink } from 'react-router-dom'

import Logo from "../../assets/Logo.png";

import overview from "../../assets/Mask Group 464.svg";
import user from "../../assets/Group 5013.svg";
import topic from "../../assets/Mask Group 468.svg";
import filled from "../../assets/Mask Group 466.svg";
import referal from "../../assets/Mask Group 467.svg";
import influencer from "../../assets/Mask Group 484.svg";
import celebrity from "../../assets/Mask Group 489.svg";
import ad from "../../assets/Mask Group 490.svg";
import setting from "../../assets/setting.svg";
import logoutImg from "../../assets/Mask Group 478.svg";
import { useAuth } from "../../contexts/AuthContext";


export default function Sidebar() {
    const { logout } = useAuth()
    const [currentId, setCurrentId] = useState("dashboard")

    function topicSer() {
        document.getElementById("topic").style.background="#1E1D2B";
    }

    async function getPath(event) {
        if(currentId !==''|| currentId !== null){
            document.getElementById(currentId).classList.remove("current")
        }
        let path = event.target.id
        setCurrentId(path)
        document.getElementById(path).classList.add("current")
        document.getElementById("topic").style.background="transparent"
            if (path === "logout") {
                await logout()
            }
        }
    return (
        <div className="sidebar">
            <div className="text-center">
                <img alt="" src={Logo} className="reel_me_logo"/>
            </div>

            <ul className="sidebar_ul">
                <NavLink to={"/dashboard"} style={{ textDecoration: 'none' }} >
                    <li id="dashboard" onClick={(event) => getPath(event)}>
                        <img alt="j" src={overview} />
                     Overview
                 </li>
                </NavLink>
                <NavLink to={"/user-management"} style={{ textDecoration: 'none' }}>
                    <li id="user-management" onClick={(event) => getPath(event)}>
                        <img alt="" src={user} />
                      User Management

                 </li>
                </NavLink>
                    <li onClick={topicSer} id="topic">
                        <img alt="" src={topic} />
                               <button class="topic-button" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne" >
                                  Topic Management
                                </button>
                            <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                               <div class="">
                                   <ul className="topic_ul">
                                   <NavLink to={"/bonus-topic"} style={{ textDecoration: 'none' }} >
                                       <li id="bonus" onClick={(event) => getPath(event)}>Bonus Topics</li>
                                    </NavLink>
                                    <NavLink to={"/adventure-topic"} style={{ textDecoration: 'none' }} >
                                       <li id="adventure" onClick={(event) => getPath(event)}>Adventure Topics</li>
                                    </NavLink>
                                    <NavLink to={"/connection-topic"} style={{ textDecoration: 'none' }} >
                                       <li id="connection" onClick={(event) => getPath(event)}>Connection Topics</li>
                                    </NavLink>
                                   </ul>
                               </div>
                            </div>
                    </li>
                <NavLink to={"/pre_comments"} style={{ textDecoration: 'none' }}>
                    <li id="pre_comments" onClick={(event) => getPath(event)}>
                        <img alt="" src={filled} />
                     Pre-Filled Comments
                 </li>
                </NavLink>
                <NavLink to={"/referrals"} style={{ textDecoration: 'none' }}>
                    <li id="referrals" onClick={(event) => getPath(event)}>
                        <img alt="" src={referal} />
                     Referrals
                 </li>
                </NavLink>
                <NavLink to={"/influencer"} style={{ textDecoration: 'none' }}>
                    <li id="influencer" onClick={(event) => getPath(event)}>
                        <img alt="" src={influencer} />
                     Influencers
                 </li>
                </NavLink>
                <NavLink to={"/celebrity"} style={{ textDecoration: 'none' }}>
                    <li id="celebrity" onClick={(event) => getPath(event)}>
                        <img alt="" src={celebrity} />
                     Celebrity
                 </li>
                </NavLink>
                <NavLink to={"/ad_revenue"} style={{ textDecoration: 'none' }}>
                    <li id="ad_revenue" onClick={(event) => getPath(event)}>
                        <img alt="" src={ad} />
                     Ad Revenue
                 </li>
                </NavLink>
            </ul>

            <ul className="logout_div sidebar_ul">
                <NavLink to={"/settings"} style={{ textDecoration: 'none' }}>
                    <li id="setting" onClick={(event) => getPath(event)}>
                        <img alt="" src={setting} />
                     Settings
                 </li>
                </NavLink>
                <NavLink to={"/login"} style={{ textDecoration: 'none' }}>
                    <li id="logout" onClick={(event) => getPath(event)}>
                        <img alt="" src={logoutImg} />
                     Logout
                 </li>
                </NavLink>
            </ul>
        </div>
    );

}