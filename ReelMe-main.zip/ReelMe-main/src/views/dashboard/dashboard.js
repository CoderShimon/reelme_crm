import React, { Component } from "react";
import "./dashboard.css";
// import { Link } from "react-router-dom";


class dashboard extends Component {
    state = {  }
    render() { 
        return ( 
            <div>
                
            </div>
         );
    }
}
 
export default dashboard;