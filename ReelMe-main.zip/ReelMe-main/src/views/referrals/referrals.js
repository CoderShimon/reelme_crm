import React, { Component } from "react";
import "./referrals.css";
import SlimSelect from 'slim-select';
import User_img from '../../assets/pablo-soriano-QU41aIQ-laQ-unsplash2.png'
// import modal_close from '../../assets/Group 2787.png'



class Referrals extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    componentDidMount=() =>{
        new SlimSelect({
            select: '#referal-select'
          })  
          new SlimSelect({
            select: '#earning-select'
          })   
      }
    render() { 
        return ( 
            <div className="referal-div">
                <div className="d-flex align-items-center justify-content-between">
                   <div className="Sort_div">
                       <p>Sort By:</p>
                        <select id="referal-select" className="slim_sort-div">
                        <option value="All Users">All Users</option>
                        <option value="Roll Model">Roll Model</option>
                        <option value="Celebrity">Celebrity</option>
                        <option value="Influencer">Influencer</option>
                        </select>

                        <p className="ml-4">Filter Earnings By:</p>
                        <select id="earning-select" className="slim_sort-div">
                        <option value="All Users">Monthly</option>
                        <option value="Roll Model">Quaterly</option>
                        <option value="Celebrity">Celebrity</option>
                        <option value="Influencer">Influencer</option>
                        </select>
                   </div>
                   <div className="invite_user-div">
                       <button className="invite_button " type="button" data-toggle="modal" data-target="#commision_modal">commission management</button>
                   </div>
                </div>
                <div className="overflow_table-div">
                <table className="user_table">
                    <tr>
                        <th>Name</th> 
                        <th>Username</th>
                        <th>User Role</th>
                        <th>Level</th>
                        <th>Commission %</th>
                        <th>Lifetime Referrals</th>
                        <th>Referral Earning</th>
                        <th>Date Joined</th>
                    </tr>
                    <tr>
                        <td><div className="d-flex align-items-center">
                                 <img alt="" src={User_img} className="table-user-img" />
                                 <p>Emma Smith</p>
                            </div>
                        </td>
                        <td>emmasmith_987</td>
                        <td>Influencer</td>
                        <td>Level 1</td>
                        <td>15%</td>
                        <td>200</td>
                        <td data-toggle="modal" data-target="#referal_modal" className="referal_earning">$2000.00</td>
                        <td>01-01-2020</td>
                    </tr>
                    <tr>
                        <td><div className="d-flex align-items-center">
                                 <img alt="" src={User_img} className="table-user-img" />
                                 <p>Emma Smith</p>
                            </div>
                        </td>
                        <td>emmasmith_987</td>
                        <td>Influencer</td>
                        <td>Level 1</td>
                        <td>15%</td>
                        <td>200</td>
                        <td data-toggle="modal" data-target="#referal_modal" className="referal_earning">$2000.00</td>
                        <td>01-01-2020</td>
                    </tr>
                    <tr>
                        <td><div className="d-flex align-items-center">
                                 <img alt="" src={User_img} className="table-user-img" />
                                 <p>Emma Smith</p>
                            </div>
                        </td>
                        <td>emmasmith_987</td>
                        <td>Influencer</td>
                        <td>Level 1</td>
                        <td>15%</td>
                        <td>200</td>
                        <td data-toggle="modal" data-target="#referal_modal" className="referal_earning">$2000.00</td>
                        <td>01-01-2020</td>
                    </tr>
                    <tr>
                        <td><div className="d-flex align-items-center">
                                 <img alt="" src={User_img} className="table-user-img" />
                                 <p>Emma Smith</p>
                            </div>
                        </td>
                        <td>emmasmith_987</td>
                        <td>Influencer</td>
                        <td>Level 1</td>
                        <td>15%</td>
                        <td>200</td>
                        <td data-toggle="modal" data-target="#referal_modal" className="referal_earning">$2000.00</td>
                        <td>01-01-2020</td>
                    </tr>
                 </table>
                </div>

    {/* Earning modal */}
                <div class="modal fade modal_position" id="referal_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog_earning" role="document">
                      <div class="modal-content modal_content_earning">
                      <button type="button" class="close modal_close" data-dismiss="modal" aria-label="Close">
                          .
                      </button>
                        <div class="modal-body px-0">
                            <table className="user_table comission_table">
                            <tr>
                                
                                <th>Username</th>
                                <th>User Role</th>
                                <th>Level</th>
                                <th>Date Joined</th>
                                <th>Josephine Olive's Commission</th>
                                <th>Lifetime Earnings</th>
                                <th>Lifetime Withdrawal</th>
                            </tr>
                            <tr>
                                <td>emmasmith_987</td>
                                <td>Influencer</td>
                                <td>Level 1</td>
                                <td>01-01-2020</td>
                                <td>$2000.00</td>
                                <td>$2000.00</td>
                                <td>$2000.00</td>
                            </tr>
                            <tr>
                                <td>emmasmith_987</td>
                                <td>Influencer</td>
                                <td>Level 1</td>
                                <td>01-01-2020</td>
                                <td>$2000.00</td>
                                <td>$2000.00</td>
                                <td>$2000.00</td>
                            </tr>
                            <tr>
                                <td>emmasmith_987</td>
                                <td>Influencer</td>
                                <td>Level 1</td>
                                <td>01-01-2020</td>
                                <td>$2000.00</td>
                                <td>$2000.00</td>
                                <td>$2000.00</td>
                            </tr>
                            <tr>
                                <td>emmasmith_987</td>
                                <td>Influencer</td>
                                <td>Level 1</td>
                                <td>01-01-2020</td>
                                <td>$2000.00</td>
                                <td>$2000.00</td>
                                <td>$2000.00</td>
                            </tr>
                            <tr>
                                <td>emmasmith_987</td>
                                <td>Influencer</td>
                                <td>Level 1</td>
                                <td>01-01-2020</td>
                                <td>$2000.00</td>
                                <td>$2000.00</td>
                                <td>$2000.00</td>
                            </tr>
                            <tr>
                                <td>emmasmith_987</td>
                                <td>Influencer</td>
                                <td>Level 1</td>
                                <td>01-01-2020</td>
                                <td>$2000.00</td>
                                <td>$2000.00</td>
                                <td>$2000.00</td>
                            </tr>
                            <tr>
                                <td>emmasmith_987</td>
                                <td>Influencer</td>
                                <td>Level 1</td>
                                <td>01-01-2020</td>
                                <td>$2000.00</td>
                                <td>$2000.00</td>
                                <td>$2000.00</td>
                            </tr>
                            <tr>
                                <td>emmasmith_987</td>
                                <td>Influencer</td>
                                <td>Level 1</td>
                                <td>01-01-2020</td>
                                <td>$2000.00</td>
                                <td>$2000.00</td>
                                <td>$2000.00</td>
                            </tr>
                            <tr>
                                <td>emmasmith_987</td>
                                <td>Influencer</td>
                                <td>Level 1</td>
                                <td>01-01-2020</td>
                                <td>$2000.00</td>
                                <td>$2000.00</td>
                                <td>$2000.00</td>
                            </tr>
                            </table>
                        </div>
                      </div>
                    </div>
                </div>
            
            
            {/* Comission modal */}
            <div class="modal fade modal_position" id="commision_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content commison_popup">
                      <button type="button" class="close modal_close" data-dismiss="modal" aria-label="Close">
                          .
                      </button>
                        <div class="modal-body com_management_modal-body">
                            <p className="modal_headtext">Commission Management</p>
                            <p className="modal_smalltext">Total Commission of User</p>
                            <div className="modal_form">
                                <label>Percentage</label>
                                <input type="text" />
                                <button className="invite_button mt-3">action</button>
                            </div>
                            </div>
                            </div>
                            </div>
                            </div>






            </div>



         );
    }
}
 
export default Referrals;