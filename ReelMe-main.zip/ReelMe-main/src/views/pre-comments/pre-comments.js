import React, { Component } from "react";
import "./pre-comments.css";
import { Link } from "react-router-dom";

class pre_comments extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( 
            <div className="comments_div">
                <div className="comment_head-div">
                    <p>Pre-Filled Comments</p>
                    <Link to={"/add_comment"}><button>Add New Comment</button></Link>
                </div>

                <div className="comment_table_overflow">
                <table className="user_table comment_table">
                    <tr>
                        <th>Comment Number</th> 
                        <th>Comment</th>
                        <th>Date Added</th>
                        <th>No. of Time</th>
                        <th>Action</th>
                    </tr>
                    <tr>
                        <td>C1-01</td>
                        <td>It was really helpful information.</td>
                        <td>01-01-2021</td>
                        <td>1000</td>
                        <td>
                            <label class="switch">
                            <input type="checkbox" />
                            <span class="slider round"></span>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <td>C1-01</td>
                        <td>It was really helpful information.</td>
                        <td>01-01-2021</td>
                        <td>1000</td>
                        <td>
                            <label class="switch">
                            <input type="checkbox" />
                            <span class="slider round"></span>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <td>C1-01</td>
                        <td>It was really helpful information.</td>
                        <td>01-01-2021</td>
                        <td>1000</td>
                        <td>
                            <label class="switch">
                            <input type="checkbox" />
                            <span class="slider round"></span>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <td>C1-01</td>
                        <td>It was really helpful information.</td>
                        <td>01-01-2021</td>
                        <td>1000</td>
                        <td>
                            <label class="switch">
                            <input type="checkbox" />
                            <span class="slider round"></span>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <td>C1-01</td>
                        <td>It was really helpful information.</td>
                        <td>01-01-2021</td>
                        <td>1000</td>
                        <td>
                            <label class="switch">
                            <input type="checkbox" />
                            <span class="slider round"></span>
                            </label>
                        </td>
                    </tr>
                   
                 </table>
                </div>
            </div>
         );
    }
}
 
export default pre_comments;