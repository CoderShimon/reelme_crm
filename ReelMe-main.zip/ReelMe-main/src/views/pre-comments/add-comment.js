import React, { Component } from "react";
import "./pre-comments.css";
import { Link } from "react-router-dom";

class Add_comment extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( 
            <div className="comments_div pre-div">
                <div className="comment_head-div">
                    <p>Add New Comment</p>
                </div>
                <div className="my-3">
                    <label className="custom_label">Comment</label>
                    <textarea type="text" className="form-custom-input textarea-height" />
                </div>
                <div className="d-flex align-items-center justify-content-between mt-3 add-cmment_button-div">
                    <button className="modal_send-btn">save</button>
                    <Link to={"/pre_comments"} style={{width:"100%"}}><button className="modal_cancel-btn">cancel</button></Link>
                               {/* <button className="modal_cancel-btn">cancel</button> */}
                </div>
                
            </div>
         );
    }
}
 
export default Add_comment;