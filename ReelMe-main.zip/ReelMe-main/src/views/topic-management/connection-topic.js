import React, { useState, useEffect } from "react"
import "./topic-management.css";
import { Link } from "react-router-dom";
import Action_btn from '../../assets/Group 5295.png'
import { useAuth } from "../../contexts/AuthContext"
import { Alert } from "react-bootstrap"
import LoadingOverlay from 'react-loading-overlay'

export default function Connection_topic() {
   const  [allTopics, setAllTopics] = useState([])
   const { collectionDetails, updateCollectionDetails, getDateFromFirestore } = useAuth()
   const [loading, setLoading] = useState(false)
   const [error, setError] = useState("")

   useEffect(() => {
      refreshTopicDetails()
     }, []);

     function refreshTopicDetails() {
      setLoading(true)
      collectionDetails("connectionTopics").then((querySnapshot) => {
          var topicData = []
          querySnapshot.forEach((doc) => {
              let docData = doc.data()
              docData.id = doc.id
              topicData.push(docData)
          });
          topicData = topicData.sort((a,b) => a.topicId > b.topicId);
          setAllTopics(topicData)
          setLoading(false)
      });
    }

    async function onHandleSwitchChange(i, active) {
      allTopics[i].enabled = !active
      try {
        setError("")
        setLoading(true)
        let doc = {
            enabled: !active
        }
        await updateCollectionDetails("connectionTopics", allTopics[i].id, doc)
        refreshTopicDetails()
      } catch(err) {
          console.log(err)
          setError("Failed....")
          setLoading(false)
      }
 }

      return ( 
         <LoadingOverlay
         active={loading}
         spinner
         text='Fetching...'
         >
        <div>
        <div className="comment_head-div mb-3">
            <p>Connection Topic</p>
            {error && <Alert variant="danger">{error}</Alert>}
            <div>
            <Link to={"/add-connection-topic"}><button className="mr-3">add new topic</button></Link>
            <Link to={"/add-group"}><button>add new Group</button></Link>
            </div>
        </div>
        <div className="comments_div">
        <div className="comment_table_overflow">
        <table className="user_table comment_table">
            <tr>
                <th>Topic Number</th> 
                <th>Group Name</th>
                <th>Topic</th>
                <th>Topic Points</th>
                <th>Action</th>
            </tr>
            { Object.keys(allTopics).map((oneKey,i)=>{
            return (
            <tr>
                <td>{allTopics[i].topicId}</td>
                <td >{allTopics[i].group.toString()}</td>
                <td className="connection-topic-td">{allTopics[i].topicDescription}</td>
                <td>{allTopics[i].points}</td>
                <td>
                <label class="switch">
                          <input type="checkbox" checked={allTopics[i].enabled} onChange = {() => 
                           onHandleSwitchChange(i, allTopics[i].enabled)}/>
                          <span class="slider round"></span>
                       </label>
                    {/* dropdown slide */}
                    <div class="dropdown upt_dropdown">
                         <img alt="" src={Action_btn} className="action_btn upd_act" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" />
                            <div class="dropdown-menu upt_dropdownmenu" aria-labelledby="dropdownMenuButton" style={{left:"-95px !important",top:"8px !important"}}>
                               <div className="statistic_div">
                                   <p className="sta-head">Topic Statistics</p>
                                   <div className="d-flex">
                                       <div className="sta-inner_div">
                                          <p>Date Added</p>
                                          <p>{getDateFromFirestore(allTopics[i].createdDate.toDate())}</p>
                                       </div>
                                       <div className="sta-inner_div">
                                          <p>No. of times used</p>
                                          <p>0</p>
                                       </div>
                                       <div className="sta-inner_div">
                                          <p>Total Reels</p>
                                          <p>0</p>
                                       </div>
                                       <div className="sta-inner_div">
                                          <p>Total Points</p>
                                          <p>0</p>
                                       </div>
                                   </div>
                               </div>
                            </div>
                       </div>
                </td>
            </tr>
            )})}
         </table>
        </div>
    </div>
    </div>
    </LoadingOverlay>
     );
}