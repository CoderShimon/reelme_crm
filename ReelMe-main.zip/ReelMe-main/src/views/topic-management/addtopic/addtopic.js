import React, { useState, useRef } from "react"
import "./addtopic.css";
import { useHistory, Link } from "react-router-dom";
import { useAuth } from "../../../contexts/AuthContext"
import LoadingOverlay from 'react-loading-overlay'
import { Alert } from "react-bootstrap"

export default function Add_topic() {
    const topicNumber = useRef()
    const topicDes = useRef()
    const points = useRef()
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState("")
    const { addTopics, checkRecordExists } = useAuth()
    const history = useHistory()
    const collectionName = "bonusTopics"

    function addTopicRequest(e) {
        e.preventDefault()
        if (!topicNumber.current.value.replace(/^\s+|\s+$/g,"")) {
            setError("Please enter correct Topic Number")
            return
        }
        if (!topicDes.current.value.replace(/^\s+|\s+$/g,"") || topicDes.current.value.length < 5) {
            setError("Please enter Topic Description of more than 5 characters")
            return
        }
        if (!points.current.value.replace(/^\s+|\s+$/g,"")) {
            setError("Please enter points")
            return
        }
        let docId = "B." + topicNumber.current.value
        setLoading(true)
        checkRecordExists(collectionName, docId).then((document) => {
            setError("")
            setLoading(false)
            if (!document.exists) {
                try {
                    setError("")
                    setLoading(true)
                    let doc = {
                        topicId: topicNumber.current.value,
                        topicDescription: topicDes.current.value,
                        points: parseInt(points.current.value),
                        enabled: true
                    }
                    addTopics(collectionName, docId, doc)
                    history.push("/bonus-topic")
                    setLoading(false)
                  } catch(err) {
                      console.log(err)
                      setError("Failed to save topic")
                      setLoading(false)
                  }
            } else {
                setError("Topic Id already exist. Please change the topic Id.")
            }
        });
        
      }

      function onHandleTopicIdChange(e) {
        let number = e.target.value.replace(/[^0-9\.]/g,'')
        topicNumber.current.value = number
    }

    function onHandlePointsChange(e) {
        let number = e.target.value.replace(/\D/,'')
        points.current.value = number
    }

      return ( 
        <div className="Topic_cont">
            <LoadingOverlay
  active={loading}
  spinner
  text='Fetching....'
  >
             <p className="topic-head">Add New Topic</p>
                    <div className="form_width-container">
                    {error && <Alert variant="danger">{error}</Alert>}
                        <div className="my-3">
                           <label className="custom_label">Topic Number</label>
                           <input type="text" ref={topicNumber} onChange = {onHandleTopicIdChange} className="form-custom-input" />
                        </div>
                        <div className="my-3">
                            <label className="custom_label">Topic</label>
                            <textarea type="text" ref={topicDes} className="form-custom-input textarea-style" />
                        </div>
                        <div className="my-3">
                           <label className="custom_label">Topic Points</label>
                           <input type="text" ref={points} onChange = {onHandlePointsChange} className="form-custom-input" />
                        </div>
                        <div className="d-flex align-items-center justify-content-between mt-3 add-cmment_button-div">
                           <button className="modal_send-btn btn-width" disabled={loading} onClick={addTopicRequest}>save</button>
                           <button className="modal_cancel-btn btn-width"><Link to={"/bonus-topic"} style={{width:"100%",textDecoration:"none",color:"white"}}>cancel</Link></button>
                           {/* <button className="modal_cancel-btn">cancel</button> */}
                        </div>
                    </div>
    </LoadingOverlay>
        </div>
     );
}