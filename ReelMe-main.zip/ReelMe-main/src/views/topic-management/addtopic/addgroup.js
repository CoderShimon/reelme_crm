import React, { useState, useRef, useEffect } from "react"
import "./addtopic.css";
import { useHistory, Link } from "react-router-dom";
import { useAuth } from "../../../contexts/AuthContext"
import LoadingOverlay from 'react-loading-overlay'
import { Alert } from "react-bootstrap"

export default function Add_group() {

    const groupNameRef = useRef()
    const [groupId, setGroupId] = useState("")
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState("")
    const { addTopics, collectionDetails } = useAuth()
    const  [groupTopics, setGroupTopics] = useState([])
    const history = useHistory()

    useEffect(() => {
      var timestamp = new Date().valueOf();
      setGroupId("G."+timestamp)
      fetchPresentGroups()
      }, []);

      function fetchPresentGroups() {
         setLoading(true)
         collectionDetails("groupNames").then((querySnapshot) => {
            var topicData = []
            querySnapshot.forEach((doc) => {
                let docData = doc.data()
                docData.id = doc.id
                topicData.push(docData)
            });
            setGroupTopics(topicData)
            setLoading(false)
        });
      }

      async function addTopicRequest(e) {
         console.log(groupId)
         e.preventDefault()
         if (!groupNameRef.current.value.replace(/^\s+|\s+$/g,"") || groupNameRef.current.value.length < 3) {
             setError("Please enter Group Description of more than 3 characters")
             return
         }
         let groupFilteredName = groupNameRef.current.value.replace(/^\s+|\s+$/g,"")

         let groupData = groupTopics.filter(function (event) {
            return event.groupName === groupFilteredName;
         });
         if (groupData.length > 0 ) {
            setError("Group already exist.")
             return
         }
 
         try {
             setError("")
             setLoading(true)
             let doc = {
                topicId: groupId,
                groupName: groupFilteredName,
             }
             await addTopics("groupNames", groupId, doc)
             history.push("/connection-topic")
             setLoading(false)
           } catch(err) {
               console.log(err)
               setError("Failed to save Group")
               setLoading(false)
           }
       }

      return ( 
         <LoadingOverlay
         active={loading}
         spinner
         text='Fetching...'
         >
        <div className="Topic_cont">
             <p className="topic-head">Add New Group</p>
             {error && <Alert variant="danger">{error}</Alert>}

                    <div className="form_width-container">
                        <div className="my-3">
                           <label className="custom_label">Group Name</label>
                           <input ref={groupNameRef} type="text" className="form-custom-input" />
                        </div>
                        <div className="d-flex align-items-center justify-content-between mt-3 add-cmment_button-div">
                        <button className="modal_send-btn btn-width" disabled={loading} onClick={addTopicRequest}>save</button>
                           <button className="modal_cancel-btn btn-width"><Link to={"/connection-topic"} style={{width:"100%",textDecoration:"none",color:"white"}}>cancel</Link></button>
                           {/* <button className="modal_cancel-btn">cancel</button> */}
                        </div>
                    </div>
        </div>
        </LoadingOverlay>
     );
}