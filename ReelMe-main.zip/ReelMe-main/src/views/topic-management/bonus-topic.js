import React, { useState, useEffect } from "react"
import "./topic-management.css";
import Action_btn from '../../assets/Group 5295.png'
import { NavLink } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext"
import { Alert } from "react-bootstrap"
import LoadingOverlay from 'react-loading-overlay'

export default function Bonus_topic() {
   const  [allTopics, setAllTopics] = useState([])
   const { collectionDetails, updateCollectionDetails, getDateFromFirestore } = useAuth()
   const [loading, setLoading] = useState(false)
   const [error, setError] = useState("")

   useEffect(() => {
      refreshTopicDetails()
     }, []);

     function refreshTopicDetails() {
      setLoading(true)
      collectionDetails("bonusTopics").then((querySnapshot) => {
          var topicData = []
          querySnapshot.forEach((doc) => {
              let docData = doc.data()
              docData.id = doc.id
              topicData.push(docData)
          });
          topicData = topicData.sort((a,b) => a.topicId > b.topicId);
          setAllTopics(topicData)
          setLoading(false)
      });
    }

    async function onHandleSwitchChange(i, active) {
       allTopics[i].enabled = !active
       try {
         setError("")
         setLoading(true)
         let doc = {
             enabled: !active
         }
         await updateCollectionDetails("bonusTopics", allTopics[i].id, doc)
         refreshTopicDetails()
       } catch(err) {
           console.log(err)
           setError("Failed....")
           setLoading(false)
       }
  }

     return ( 
        
      <div className="topic_div bonus_topic-div">
         <LoadingOverlay
  active={loading}
  spinner
  text='Fetching....'
  >
            <div className="d-flex justify-content-between align-items-center">
                <p className="topic_head">Bonus Topic</p>
                <div>
                   <NavLink to={'/add-topic'}><button className="add_topic-btn">Add New topic</button></NavLink> 
                </div>
            </div>
            {error && <Alert variant="danger">{error}</Alert>}
            <table className="bonus_table">
            { Object.keys(allTopics).map((oneKey,i)=>{
            return (
               <tr>
                    <td>
                        <p>Topic Number</p>
                        <p>{allTopics[i].topicId}</p>
                    </td>
                    <td className="middle_td">
                        <p>Topic</p>
                        <p>{allTopics[i].topicDescription}</p>
                    </td>
                    <td>
                        <p>Topic Points</p>
                        <p>{allTopics[i].points}</p>
                    </td>
                    <td className="last_td">
                    {/* <p className="visiblity-hidden">head</p> */}
                       <label class="switch">
                          <input type="checkbox" checked={allTopics[i].enabled} onChange = {() => 
                           onHandleSwitchChange(i, allTopics[i].enabled)}/>
                          <span class="slider round"></span>
                       </label>
                       {/* dropdown slide */}
                       <div class="dropdown upt_dropdown">
                         <img alt="" src={Action_btn} className="action_btn upd_act" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" />
                            <div class="dropdown-menu upt_dropdownmenu bonus_stats-div" aria-labelledby="dropdownMenuButton" style={{left:"-95px !important",top:"8px !important"}}>
                               <div className="statistic_div ">
                                   <p className="sta-head">Topic Statistics</p>
                                   <div className="d-flex">
                                       <div className="sta-inner_div">
                                          <p>Date Added</p>
                                          <p>{getDateFromFirestore(allTopics[i].createdDate.toDate())}</p>
                                       </div>
                                       <div className="sta-inner_div">
                                          <p>No. of times used</p>
                                          <p>0</p>
                                       </div>
                                       <div className="sta-inner_div">
                                          <p>Total Reels</p>
                                          <p>0</p>
                                       </div>
                                       <div className="sta-inner_div">
                                          <p>Total Points</p>
                                          <p>0</p>
                                       </div>
                                   </div>
                               </div>
                            </div>
                       </div>
                    </td> 
                </tr>
            );
            })
            }
            </table>
            </LoadingOverlay>
      </div>
   );
}