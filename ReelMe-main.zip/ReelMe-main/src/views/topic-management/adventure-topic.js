import React, { useState, useEffect } from "react"
import "./topic-management.css";
import Action_btn from '../../assets/Group 5295.png';
import { NavLink } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext"
import LoadingOverlay from 'react-loading-overlay'
import { Alert } from "react-bootstrap"

export default function Adventure_topic() {
    const [loading, setLoading] = useState(false)
    const { collectionDetails, getDateFromFirestore, updateCollectionDetails } = useAuth()
    const  [groupATopics, setGroupATopics] = useState([])
    const  [groupBTopics, setGroupBTopics] = useState([])
    const [error, setError] = useState("")

    useEffect(() => {
        refreshTopicDetails()
      }, []);

      function refreshTopicDetails() {
        setLoading(true)
        collectionDetails("adventureTopics").then((querySnapshot) => {
            var topicData = []
            querySnapshot.forEach((doc) => {
                let docData = doc.data()
                docData.id = doc.id
                topicData.push(docData)
            });
            topicData = topicData.sort((a,b) => a.topicId > b.topicId);
            let topicA = topicData.filter(function (e) {
                return e.type === "A";
            });
            let topicB = topicData.filter(function (e) {
                return e.type === "B";
            });
            setGroupATopics(topicA)
            setGroupBTopics(topicB)
            setLoading(false)
        });
      }

      async function onHandleSwitchChange(i, active, group) {
          var id = ""
        if (group === "A") {
            groupATopics[i].enabled = !active
            id = groupATopics[i].id
        } else {
            groupBTopics[i].enabled = !active
            id = groupBTopics[i].id
        }
        try {
          setError("")
          setLoading(true)
          let doc = {
              enabled: !active
          }
          await updateCollectionDetails("adventureTopics", id, doc)
          refreshTopicDetails()
        } catch(err) {
            console.log(err)
            setError("Failed to save....")
            setLoading(false)
        }
   }

      return ( 
        <LoadingOverlay
        active={loading}
        spinner
        text='Fetching....'
        >
        <div className="row">

            {/* left side section */}
            {error && <Alert variant="danger">{error}</Alert>}
            <div className="col-md-6">
        
        <div className="topic_div">
        <div className="d-flex justify-content-between align-items-center">
            <p className="topic_head">Group A</p>
            <div>
            <NavLink to={{
                   pathname:'/add-topic_groups',
                   state: {from:'A'}
            }}><button className="add_topic-btn">Add New topic</button></NavLink>
            </div>
        </div>
        <div className="topic_inner">
        <table className="bonus_table">
        { Object.keys(groupATopics).map((oneKey,i)=> {
            return (
            <tr>
                <td>
                    <p>Topic Number</p>
                    <p>{groupATopics[i].topicId}</p>
                </td>
                <td className="adv_middle-td">
                    <p>Topic</p>
                    <p>{groupATopics[i].topicDescription}</p>
                </td>
                <td>
                    <p>Topic Points</p>
                    <p>{groupATopics[i].points}</p>
                </td>
                <td>
                    <p>Masked Points</p>
                    <p>{groupATopics[i].maskedPoints}</p>
                </td>
                <td>
                    <label class="switch">
                        <input type="checkbox" checked={groupATopics[i].enabled} onChange = {() => 
                            onHandleSwitchChange(i, groupATopics[i].enabled, "A")}/>
                        <span class="slider round"></span>
                    </label>
                </td>
                <td className="last_td">
                    {/* dropdown slide */}
                    <div class="dropdown upt_dropdown">
                         <img alt="" src={Action_btn} className="action_btn upd_act" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" />
                            <div class="dropdown-menu upt_dropdownmenu" aria-labelledby="dropdownMenuButton" style={{left:"-95px !important",top:"8px !important"}}>
                               <div className="statistic_div">
                                   <p className="sta-head">Topic Statistics</p>
                                   <div className="d-flex">
                                       <div className="sta-inner_div adv-inner_div">
                                          <p>Date Added</p>
                                          <p>{getDateFromFirestore(groupATopics[i].createdDate.toDate())}</p>
                                       </div>
                                       <div className="sta-inner_div adv-inner_div">
                                          <p>No. of times used</p>
                                          <p>0</p>
                                       </div>
                                       <div className="sta-inner_div adv-inner_div">
                                          <p>Total Reels</p>
                                          <p>0</p>
                                       </div>
                                       <div className="sta-inner_div adv-inner_div">
                                          <p>Total Points</p>
                                          <p>0</p>
                                       </div>
                                   </div>
                               </div>
                            </div>
                       </div>
                </td> 
            </tr>
            )
        })}
        </table>
        </div>
  </div>
  </div>

  {/* right side section */}
      
  <div className="col-md-6">
        
        <div className="topic_div">
        <div className="d-flex justify-content-between align-items-center">
            <p className="topic_head">Group B</p>
            <div>
            <NavLink to={{
                   pathname:'/add-topic_groups',
                   state: {from:'B'}
            }}>
            <button className="add_topic-btn">Add New topic</button></NavLink>
            </div>
        </div>
        <div className="topic_inner">
        <table className="bonus_table">
        { Object.keys(groupBTopics).map((oneKey,i)=> {
            return (
            <tr>
                <td>
                    <p>Topic Number</p>
                    <p>{groupBTopics[i].topicId}</p>
                </td>
                <td className="adv_middle-td">
                    <p>Topic</p>
                    <p>{groupBTopics[i].topicDescription}</p>
                </td>
                <td>
                    <p>Topic Points</p>
                    <p>{groupBTopics[i].points}</p>
                </td>
                <td>
                    <p>Masked Points</p>
                    <p>{groupBTopics[i].maskedPoints}</p>
                </td>
                <td>
                    <label class="switch">
                        <input type="checkbox" checked={groupBTopics[i].enabled} onChange = {() => 
                            onHandleSwitchChange(i, groupBTopics[i].enabled, "B")}/>
                        <span class="slider round"></span>
                    </label>
                </td>
                <td className="last_td">
                    {/* dropdown slide */}
                       <div class="dropdown upt_dropdown">
                         <img alt="" src={Action_btn} className="action_btn upd_act" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" />
                            <div class="dropdown-menu upt_dropdownmenu" aria-labelledby="dropdownMenuButton" style={{left:"-95px !important",top:"8px !important"}}>
                               <div className="statistic_div">
                                   <p className="sta-head">Topic Statistics</p>
                                   <div className="d-flex">
                                       <div className="sta-inner_div adv-inner_div ">
                                          <p>Date Added</p>
                                          <p>{getDateFromFirestore(groupBTopics[i].createdDate.toDate())}</p>
                                       </div>
                                       <div className="sta-inner_div adv-inner_div">
                                          <p>No. of times used</p>
                                          <p>0</p>
                                       </div>
                                       <div className="sta-inner_div adv-inner_div">
                                          <p>Total Reels</p>
                                          <p>0</p>
                                       </div>
                                       <div className="sta-inner_div adv-inner_div">
                                          <p>Total Points</p>
                                          <p>0</p>
                                       </div>
                                   </div>
                               </div>
                            </div>
                       </div>
                </td> 
            </tr> )})}
        </table>
        </div>
  </div>
  </div>


  {/* Statistics  modal */}
  <div class="modal fade modal_position" id="Stats_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                  <button type="button" class="close modal_close" data-dismiss="modal" aria-label="Close">
                      .
                  </button>
                    <div class="modal-body com_management_modal-body">  
                    <div className="statistic_div">
                                     <p className="sta-head">Topic Statistics</p>
                                     <div className="d-flex">
                                         <div className="sta-inner_div adv-inner_div">
                                            <p>Date Added</p>
                                            <p>01-01-21</p>
                                         </div>
                                         <div className="sta-inner_div adv-inner_div">
                                            <p>No. of times used</p>
                                            <p>1000</p>
                                         </div>
                                         <div className="sta-inner_div adv-inner_div">
                                            <p>Total Reels</p>
                                            <p>1000</p>
                                         </div>
                                         <div className="sta-inner_div adv-inner_div">
                                            <p>Total Points</p>
                                            <p>1000</p>
                                         </div>
                                     </div>
                                 </div>
                        </div>
                        </div>
                        </div>
                        </div>

                        {/* Modal_ends */}

</div>
</LoadingOverlay>
     );
}