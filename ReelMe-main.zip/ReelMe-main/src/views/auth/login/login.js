import React, { useRef, useState } from "react"
import "../auth.css";
import { useAuth } from "../../../contexts/AuthContext"
import { Form, Button,  Alert } from "react-bootstrap"
import {  useHistory, NavLink } from "react-router-dom"

import Logo from '../../../assets/Logo.png'

export default function Login() {
    const emailRef = useRef()
  const passwordRef = useRef()
    const [error, setError] = useState("")
    const [loading, setLoading] = useState(false)
    const { login } = useAuth()
    const history = useHistory()

    async function handleSubmit(e) {    
        e.preventDefault()

        try {
          setError("")
          setLoading(true)
          await login(emailRef.current.value, passwordRef.current.value)
          history.push("/")

        } catch {
            setError("Failed to Login. Invalid credentials.")
        }
        setLoading(false)
      }
    return ( 
        <div className="Login_container">
            <div className="login_inner-div">
                <div className="m-auto w-100">
                <img src={Logo} className="login-logo"  alt=""/>
                <p className="login_head">Welcome Back to <br/> ReelMe Administration Panel</p>
                <p className="login_subhead mt-3">Please enter your email address and password to login</p>
                <div className="login_form-div">
                {error && <Alert variant="danger">{error}</Alert>}
                <Form onSubmit={handleSubmit}>
            <Form.Group id="email">
              <Form.Control type="email" ref={emailRef} className="form-custom-input" placeholder="Email" required />
            </Form.Group>
            <Form.Group id="password">
              <Form.Control type="password" ref={passwordRef} className="form-custom-input"  placeholder="Password" required />
            </Form.Group>
            <div className="d-flex justify-content-between">
                        <p className="login_subhead remember">
                            <span>
                               <input type="checkbox" className="custom_checkbox_original mr-2" />
                            </span>Remember this device
                        </p>
                        <NavLink to={'/forgetPassword'} style={{textDecoration:"none"}}><p className="login_subhead forget">Forgot your password?</p></NavLink>
            </div>
            <Button disabled={loading} className="modal_send-btn mt-4"  type="submit">
              Log In
            </Button>
          </Form> 
          </div>
                </div>
            </div>
        </div>
     );
}