import React, { useState, useEffect } from "react"
import { useAuth } from "../../contexts/AuthContext"
import "./usermanagement.css";
import SlimSelect from 'slim-select';
import "../../assets/slim.css"
import Action_btn from '../../assets/Group 5295.png'

import stats from '../../assets/Group 5295.png' ;

import block_icon from '../../assets/delete.png'
import delete_icon from '../../assets/block.png'
import LoadingOverlay from 'react-loading-overlay'
import { Alert } from "react-bootstrap"

export default function User_management() {
    const [error, setError] = useState("")
    const [loading, setLoading] = useState(false)
    const { collectionDetails, updateCollectionDetails, deleteUserPermanent } = useAuth()
    const  [allUsers, setAllUsers] = useState([])

    useEffect(() => {
        refreshUserDetails()
        new SlimSelect({
            select: '#slim-select'
          })  ;

      }, []);

      async function blockMultipleUser(id, isBlocked) {
        try {
            setError("")
            setLoading(true)
            let doc = {
                isBlocked: isBlocked === undefined ? true : !isBlocked
            }
            await updateCollectionDetails("users", id, doc)
            refreshUserDetails()
        } catch(err) {
              console.log(err)
              setLoading(false)
              setError("Failed....")
          }
      }

      function refreshUserDetails() {
        setLoading(true)
        collectionDetails("users").then((querySnapshot) => {
            var userData = []
            querySnapshot.forEach((doc) => {
                let docData = doc.data()
                docData.id = doc.id
                userData.push(docData)
            });
            setAllUsers(userData)
            setLoading(false)
        });
      }
      
      async function deleteMutlipleUser(id) {
        setLoading(true)
        try {
            setError("")
            setLoading(true)
            await deleteUserPermanent(id)
            refreshUserDetails()
        } catch(err) {
            setError("Failed to delete...")
            setLoading(false)
      }     
    }
    
      return ( 
          
        <div className="User_management-container">
             <LoadingOverlay
  active={loading}
  spinner
  text='Fetching....'
  >
            <div className="d-flex align-items-center justify-content-between">
               <div className="Sort_div">
                   <p>Sort By:</p>
                    <select id="slim-select" className="slim_sort-div">
                    <option value="All Users">All Users</option>
                    <option value="Roll Model">Roll Model</option>
                    <option value="Celebrity">Celebrity</option>
                    <option value="Influencer">Influencer</option>
                    </select>
               </div>
               <div className="invite_user-div">
                   <button className="invite_button" type="button" data-toggle="modal" data-target="#Invite_user">invite user</button>
                   <p>{allUsers.length} Registered Users</p>
               </div>
            </div>
            <div className="overflow_table-div">
            {error && <Alert variant="danger">{error}</Alert>}
            <table className="user_table">
                <tr>
                    <th><input type="checkbox" className="custom_checkbox_original" /></th>
                    <th>Name</th> 
                    <th>Total Score</th>
                    <th>Number of Reels</th>
                    <th>Last Activity Date</th>
                    <th>User Role</th>
                    <th>Level</th>
                    <th>Join Date</th>
                    <th>Action</th>
                </tr>
                {
          Object.keys(allUsers).map((oneKey,i)=>{
            return (
                <tr>
                    <td><input type="checkbox" className="custom_checkbox_original" /></td>
                    <td><div className="d-flex align-items-center">
                             <img alt="" src={allUsers[i].profilePic} className="table-user-img" />
                             <p>{allUsers[i].firstName === null ? allUsers[i].emailId : allUsers[i].firstName + " " + allUsers[i].secondName}</p>
                        </div>
                    </td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td> {/* dropdown slide */}
                         <div class="dropdown upt_dropdown">
                           <img alt="" src={Action_btn} className="action_btn" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" />
                              <div class="dropdown-menu upt_dropdownmenu" aria-labelledby="dropdownMenuButton" style={{left:"-95px !important",top:"8px !important"}}>
                              <div class="edit-dropdown">
                                      <button className="trans-button dropdown-buttons" onClick={() => blockMultipleUser(allUsers[i].id, allUsers[i]?.isBlocked)}><span><img alt="" src={block_icon} /></span>{allUsers[i].isBlocked ? 'Unblock': 'Block'}</button>
                                      <button className="trans-button dropdown-buttons" onClick={() => deleteMutlipleUser(allUsers[i].id)}><span><img alt="" src={delete_icon} /></span>Delete User</button>
                                      <button className="trans-button dropdown-buttons" type="button" data-toggle="modal" data-target="#Stats_modal"><span><img alt="" src={stats} /></span>View Statistics</button>
                                 </div>
                              </div>
                         </div></td>
                </tr>
              )
          })
            }
             </table>
            </div>

{/* InviteUser modal */}
                <div class="modal fade modal_position" id="Invite_user" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content modal_invite-content">
                    {/* <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div> */}
                    <div class="modal-body">
                        <p className="modal-head">Invite User</p>
                        <div className="my-3">
                           <label className="custom_label">Name</label>
                           <input type="text" className="form-custom-input" />
                        </div>
                        <div className="my-3">
                           <label className="custom_label">Contact Number</label>
                           <input type="text" className="form-custom-input" />
                        </div>
                        <div className="my-3">
                           <label className="custom_label">Email Address</label>
                           <input type="email" className="form-custom-input" />
                        </div>
                        <div className="d-flex align-items-center justify-content-between mt-3">
                           <button className="modal_send-btn">send</button>
                           <button className="modal_cancel-btn" data-dismiss="modal" aria-label="Close">cancel</button>
                        </div>

                    </div>
                    
                    </div>
                </div>
                </div>

                 {/* Statistics  modal */}
  <div class="modal fade modal_position" id="Stats_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                  <button type="button" class="close modal_close" data-dismiss="modal" aria-label="Close">
                      .
                  </button>
                    <div class="modal-body com_management_modal-body">  
                    <div className="statistic_div">
                                     <p className="sta-head">User Statistics</p>
                                     <div className="d-flex">
                                         <div className="sta-inner_div">
                                            <p>Date Added</p>
                                            <p>01-01-21</p>
                                         </div>
                                         <div className="sta-inner_div">
                                            <p>No. of times used</p>
                                            <p>1000</p>
                                         </div>
                                         <div className="sta-inner_div">
                                            <p>Total Reels</p>
                                            <p>1000</p>
                                         </div>
                                         <div className="sta-inner_div">
                                            <p>Total Points</p>
                                            <p>1000</p>
                                         </div>
                                     </div>
                                 </div>
                        </div>
                        </div>
                        </div>
                        </div>
                        {/* Modal_ends */}
                        </LoadingOverlay>
        </div>

     );
}