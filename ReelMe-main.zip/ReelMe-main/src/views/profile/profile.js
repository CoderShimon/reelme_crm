import React, { useRef, useState, useEffect } from "react"
import "./profile.css";
import User_img from '../../assets/avtar.png'
import { useAuth } from "../../contexts/AuthContext"
import LoadingOverlay from 'react-loading-overlay'
import { Alert } from "react-bootstrap"
import {  useHistory } from "react-router-dom"

export default function Profile() {
    const { currentUser, updateUserProfile, updatePassword, storage } = useAuth()
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState("")
    const [success, setSuccess] = useState("")
    const userName = useRef()
    const password = useRef()
    const email = useRef()
    const history = useHistory()
    const [imageAsFile, setImageAsFile] = useState("")
    const [imageToShow, setImageToShow] = useState(User_img)

    useEffect(() => {
        userName.current.value = currentUser.displayName
        email.current.value = currentUser.email
        setImageToShow((currentUser.photoURL == undefined || currentUser.photoURL === null) ? User_img : currentUser.photoURL)
      }, []);

      async function saveUserProfile(e) {
        e.preventDefault()
        if (!userName.current.value.replace(/^\s+|\s+$/g,"") || userName.current.value.length < 5) {
            setError("Please enter correct full name")
            return
        }


        try {
            setError("")
            setLoading(true)
            await handleFireBaseUpload(e)

            let doc = {
                displayName: userName.current.value,
                email: email.current.value
            }
            await updateUserProfile(doc)
            setSuccess("Profile Updated Successfully")
            setTimeout(() => {
                setSuccess("")
                if (imageToShow === User_img) {
                    history.push("/settings")
                }
              }, 3000);
            setLoading(false)
          } catch(err) {
              console.log(err)
              setError("Failed to save topic")
              setLoading(false)
          }
      }

      async function savePassword(e) {
        if (!password.current.value.replace(/^\s+|\s+$/g,"") || password.current.value.length < 6) {
            setError("Please enter correct password.")
            return
        }

        try {
            setError("")
            setLoading(true)
            await updatePassword(password.current.value)
            setSuccess("Password Saved Successfully")
            setLoading(false)
            setTimeout(() => {
                setSuccess("")
                password.current.value = ""
              }, 2000);
          } catch(err) {
              console.log(err)
              setError("Failed to save Password. Please logout and login again")
              setLoading(false)
              setTimeout(() => {
                setError("")
              }, 2000);
          }
      }

      const handleImageAsFile = (e) => {
        const image = e.target.files[0]
        console.log('image----')
        setImageToShow(URL.createObjectURL(image))
        setImageAsFile(imageFile => (image))
    }

    async function handleFireBaseUpload(e) {
        e.preventDefault()
      console.log('start of upload')
      // async magic goes here...
      if(imageAsFile === "") {
        console.error(`not an image, the image file is a ${typeof(imageAsFile)}`)
        return
      }
      const uploadTask = storage.ref(`/adminImage/${imageAsFile.name}`).put(imageAsFile)
      //initiates the firebase side uploading 
      uploadTask.on('state_changed', 
      (snapShot) => {
        //takes a snap shot of the process as it is happening
        console.log(snapShot)
      }, (err) => {
        //catches the errors
        console.log(err)
      }, () => {
        // gets the functions from storage refences the image storage in firebase by the children
        // gets the download url then sets the image from firebase as the value for the imgUrl key:
        storage.ref('adminImage').child(imageAsFile.name).getDownloadURL()
         .then(fireBaseUrl => {
                console.log('Uploaded--',fireBaseUrl)
                setError("")
                setLoading(true)    
                let doc = {
                    photoURL: fireBaseUrl
                }
                updateUserProfile(doc).then(() => {
                setSuccess("Pic Updated Successfully")
                setTimeout(() => {
                    setSuccess("")
                    history.push("/settings")
                  }, 2000);
                setLoading(false)
                }
                ).catch((err) => {
                  console.log(err)
                  setError("Failed to upload image")
                  setLoading(false)
                    }
                )
         })
      })
      }

      function handleImageRemove() {
        setError("")
        setLoading(true)    
        let doc = {
            photoURL: null
        }
        updateUserProfile(doc).then(() => {
        setSuccess("Pic Removed Successfully")
        setTimeout(() => {
            setSuccess("")
            setImageToShow(User_img)
            history.push("/settings")
          }, 2000);
        setLoading(false)
        }
        ).catch((err) => {
          console.log(err)
          setError("Failed to remove image")
          setLoading(false)
            }
        )
      }

    return (
        <LoadingOverlay
        active={loading}
        spinner
        text='Fetching....'
        >
        <div className="profile_div">
            {error && <Alert variant="danger">{error}</Alert>}
            {success && <Alert variant="success">{success}</Alert>}
            <div className="small-width-div">
          <p className="profile_heading">Avatar</p>
          <div className="d-flex mt-3 align-items-center">
              <img src={imageToShow} className="user-img" alt=""/>
              <div>
              <input type="file" class="custom-file-inputs" onChange={handleImageAsFile} />
                <button className="modal_cancel-btn update_btn" onClick={handleImageRemove}>remove</button>
              </div>
          </div>
          <div className="d-flex align-items-center justify-content-between mt-3 mb-2">
                <p className="profile_heading">Personal Information</p>
                <div>
                    <button className="select-btn right-btn" disabled={loading} onClick={saveUserProfile}>.</button>
                </div>
          </div>
          <div className="d-flex">
            <div className="mr-4">
                <label className="custom_label">Full Name</label>
                <input type="text" ref={userName} className="form-custom-input" />
            </div>
         </div>

         <div className="d-flex align-items-center justify-content-between mt-4 mb-2">
                <p className="profile_heading">Email Address</p>
                <div>
                    <button className="select-btn edit-btn" >.</button>
                </div>
          </div>
          <div className="d-flex">
            <div className="mr-4">
                <input type="text" ref={email} className="form-custom-input" />
            </div>
         </div>

         <div className="d-flex align-items-center justify-content-between mt-4 mb-2">
                <p className="profile_heading">Password</p>
                <div>
                    <button className="select-btn edit-btn" >.</button>
                </div>
          </div>
          <div className="d-flex">
            <div className="mr-4">
                <input type="text" ref={password} className="form-custom-input" />
            </div>
         </div>
          
          <button className="invite_button mt-4 change_pass-btn" onClick={savePassword}>Change Password</button>
        </div>
        </div>
        </LoadingOverlay>
    );
}