import React, { Component } from "react";
import "./ad-revenue.css";
import { TabContent, TabPane, Nav, NavItem, NavLink,Row, Col } from 'reactstrap';
import classnames from 'classnames';

import User_img from '../../assets/pablo-soriano-QU41aIQ-laQ-unsplash2.png'
import green_tick from '../../assets/Group 5471.png'
import download from '../../assets/Mask Group 491.png'

class Ad_revenue extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            activeTab: '1'
         }

    }
   
     toggle = (tab) => {
        if(this.state.activeTab !== tab) this.setState({activeTab:tab});
      }
    render() { 
        return ( 
            <div className="revenue_div">
                <div className="revenue-section">
                    <div className="row mb-3">
                        <div className="col-md-3 pr-0">
                            <div className="Earning-div Earning-div-active">
                                <div className="">
                                <p className="Big_number">$300.45</p>
                                <p className="big_number-para">Today Earning</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-3 pr-0">
                            <div className="Earning-div d-flex align-items-center justify-content-between small_Earning-div">
                                <p className="Small_number-para">Yesterday <br/>Earning</p>
                                <p className="Small_number">$300.45</p> 
                            </div>
                            <div className="Earning-div d-flex align-items-center justify-content-between small_Earning-div">
                                <p className="Small_number-para">This<br/> Week</p>
                                <p className="Small_number">$300.45</p>
                            </div>
                        </div>
                        <div className="col-md-3">
                            <div className="Earning-div d-flex align-items-center justify-content-between small_Earning-div">
                                <p className="Small_number-para">This <br/>Month</p>
                                <p className="Small_number">$300.45</p> 
                            </div>
                            <div className="Earning-div d-flex align-items-center justify-content-between small_Earning-div">
                                <p className="Small_number-para">Lifetime<br/> Earning</p>
                                <p className="Small_number">$300.45</p>
                            </div>
                        </div>
                    </div>
                    <p className="big_number-para mb-2">Commissions</p>
                    <div className="row">
                        <div className="col-md-3 pr-0">
                            <div className="Earning-div d-flex align-items-center justify-content-between small_Earning-div">
                                <p className="Small_number-para">Lifetime <br/>Commission</p>
                                <p className="Small_number">$300.45</p> 
                            </div>
                        </div>
                        <div className="col-md-3 pr-0">
                            <div className="Earning-div d-flex align-items-center justify-content-between small_Earning-div">
                                <p className="Small_number-para">Paid <br/>Commission</p>
                                <p className="Small_number">$300.45</p> 
                            </div>
                        </div>
                        <div className="col-md-3">
                            <div className="Earning-div d-flex align-items-center justify-content-between small_Earning-div">
                                <p className="Small_number-para">Unpaid <br/>Commission</p>
                                <p className="Small_number">$300.45</p> 
                            </div>
                        </div>
                </div>
            </div>
            {/* first section ends */}

            <div className="revenue-section mt-3">
                <Nav tabs>
                    <NavItem>
                    <NavLink
                        className={classnames({ active: this.state.activeTab === '1' })}
                        onClick={() => { this.toggle('1'); }}>
                        Transaction History
                    </NavLink>
                    </NavItem>
                    <NavItem>
                    <NavLink
                        className={classnames({ active: this.state.activeTab === '2' })}
                        onClick={() => { this.toggle('2'); }}>
                         Payout Management
                    </NavLink>
                    </NavItem>
                </Nav>
                <TabContent activeTab={this.state.activeTab}>
                    <TabPane tabId="1">
                    <Row>
                        <Col sm="12">
                        <table className="user_table">
                    <tr>
                        <th>Transaction ID</th> 
                        <th>Username</th>
                        <th>User Role</th>
                        <th>Transaction</th>
                        <th>Requested Date</th>
                        <th>Status</th>
                        <th>Download Invoice</th>
                    </tr>
                    <tr>
                        <td><div className="d-flex align-items-center">
                                 <img alt="" src={User_img} className="table-user-img" />
                                 <p>24bs5cs</p>
                            </div>
                        </td>
                        <td>emmasmith_987</td>
                        <td>Influencer</td>
                        <td>$100.00</td>
                        <td>01-01-2021</td>
                        <td>
                            <div className="">
                                <select className="paid-select">
                                <option value="paid">Paid</option>
                                <option value="unpaid">Unpaid</option>
                                </select>
                            </div>
                        </td>
                        <td><button className="trans-button"><img alt="" src={download} className="download-img"/></button></td>
                    </tr>
                    <tr>
                        <td><div className="d-flex align-items-center">
                                 <img alt="" src={User_img} className="table-user-img" />
                                 <p>24bs5cs</p>
                            </div>
                        </td>
                        <td>emmasmith_987</td>
                        <td>Influencer</td>
                        <td>$100.00</td>
                        <td>01-01-2021</td>
                        <td>
                            <div className="">
                                <select className="paid-select">
                                <option value="paid">Paid</option>
                                <option value="unpaid">Unpaid</option>
                                </select>
                            </div>
                        </td>
                        <td><button className="trans-button"><img alt="" src={download} className="download-img"/></button></td>
                    </tr>
                    <tr>
                        <td><div className="d-flex align-items-center">
                                 <img alt="" src={User_img} className="table-user-img" />
                                 <p>24bs5cs</p>
                            </div>
                        </td>
                        <td>emmasmith_987</td>
                        <td>Influencer</td>
                        <td>$100.00</td>
                        <td>01-01-2021</td>
                        <td>
                            <div className="">
                                <select className="paid-select">
                                <option value="paid">Paid</option>
                                <option value="unpaid">Unpaid</option>
                                </select>
                            </div>
                        </td>
                        <td><button className="trans-button"><img alt="" src={download} className="download-img"/></button></td>
                    </tr>
                    <tr>
                        <td><div className="d-flex align-items-center">
                                 <img alt="" src={User_img} className="table-user-img" />
                                 <p>24bs5cs</p>
                            </div>
                        </td>
                        <td>emmasmith_987</td>
                        <td>Influencer</td>
                        <td>$100.00</td>
                        <td>01-01-2021</td>
                        <td>
                            <div className="">
                                <select className="paid-select">
                                <option value="paid">Paid</option>
                                <option value="unpaid">Unpaid</option>
                                </select>
                            </div>
                        </td>
                        <td><button className="trans-button"><img alt="" src={download} className="download-img"/></button></td>
                    </tr>
                 </table>
                        </Col>
                    </Row>
                    </TabPane>
                    <TabPane tabId="2">
                    <Row>
                        <Col sm="12">
                        <table className="user_table">
                    <tr>
                        <th>Requested ID</th> 
                        <th>Username</th>
                        <th>User Role</th>
                        <th>Bank Details</th>
                        <th>Requested Amount</th>
                        <th>Requested Date</th>
                        <th>Due Date</th>
                        <th>Status</th>
                    </tr>
                    <tr>
                        <td><div className="d-flex align-items-center">
                                 <img alt="" src={User_img} className="table-user-img" />
                                 <p>24bs5cs</p>
                            </div>
                        </td>
                        <td>emmasmith_987</td>
                        <td>Influencer</td>
                        <td  data-toggle="modal" data-target="#Bank_details" className="referal_earning">Click here</td>
                        <td>$100.00</td>
                        <td>01-01-2021</td>
                        <td>01-01-2021</td>
                        <td>
                            <div className="">
                                <select className="paid-select">
                                <option value="paid">Paid</option>
                                <option value="unpaid">Unpaid</option>
                                </select>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td><div className="d-flex align-items-center">
                                 <img alt="" src={User_img} className="table-user-img" />
                                 <p>24bs5cs</p>
                            </div>
                        </td>
                        <td>emmasmith_987</td>
                        <td>Influencer</td>
                        <td  data-toggle="modal" data-target="#Bank_details" className="referal_earning">Click here</td>
                        <td>$100.00</td>
                        <td>01-01-2021</td>
                        <td>01-01-2021</td>
                        <td>
                            <div className="">
                                <select className="paid-select">
                                <option value="paid">Paid</option>
                                <option value="unpaid">Unpaid</option>
                                </select>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td><div className="d-flex align-items-center">
                                 <img alt="" src={User_img} className="table-user-img" />
                                 <p>24bs5cs</p>
                            </div>
                        </td>
                        <td>emmasmith_987</td>
                        <td>Influencer</td>
                        <td  data-toggle="modal" data-target="#Bank_details" className="referal_earning">Click here</td>
                        <td>$100.00</td>
                        <td>01-01-2021</td>
                        <td>01-01-2021</td>
                        <td>
                            <div className="">
                                <select className="paid-select">
                                <option value="paid">Paid</option>
                                <option value="unpaid">Unpaid</option>
                                </select>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td><div className="d-flex align-items-center">
                                 <img alt="" src={User_img} className="table-user-img" />
                                 <p>24bs5cs</p>
                            </div>
                        </td>
                        <td>emmasmith_987</td>
                        <td>Influencer</td>
                        <td  data-toggle="modal" data-target="#Bank_details" className="referal_earning">Click here</td>
                        <td>$100.00</td>
                        <td>01-01-2021</td>
                        <td>01-01-2021</td>
                        <td>
                            <div className="">
                                <select className="paid-select">
                                <option value="paid">Paid</option>
                                <option value="unpaid">Unpaid</option>
                                </select>
                            </div>
                        </td>
                    </tr>
                 </table>
                        </Col>
                    </Row>
                    </TabPane>
                </TabContent>
            </div>

            {/* Bank details modal */}

            <div class="modal fade" id="Bank_details" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog bank_detail_dialog" role="document">
                      <div class="modal-content modal_content_earning">
                      <button type="button" class="close modal_close" data-dismiss="modal" aria-label="Close">
                          .
                      </button>
                        <div class="modal-body com_management_modal-body">
                            <p className="modal_headtext mb-3">Bank details of username</p>
                            <div className="modal_form d-flex justify-content-between">
                                <div className="width_ninty">
                                  <label>Bank Name</label>
                                  <input type="text" className="w-100" />
                                </div>
                                <div className="width_ninty">
                                  <label>Routing Number</label>
                                  <input type="text" className="w-100" />
                                </div>
                            </div>
                            <div className="modal_form d-flex justify-content-between mt-3">
                                <div className="width_ninty">
                                  <label>Account Number</label>
                                  <input type="text" className="w-100" />
                                </div>
                                <div className="width_ninty">
                                  <label>Account Type</label>
                                  <input type="text" className="w-100" />
                                </div>
                            </div>
                            <div className="modal_form d-flex justify-content-between mt-3">
                                <div className="width_ninty">
                                  <label>Address</label>
                                  <textarea></textarea>
                                </div>
                            </div>
                            <div className="modal_form d-flex justify-content-between mt-3">
                                <div className="width_ninty">
                                  <label>City and state/province</label>
                                  <input type="text" className="w-100" />
                                </div>
                                <div className="width_ninty">
                                  <label>Country</label>
                                  <input type="text" className="w-100" />
                                </div>
                            </div>

                            <p className="w9-form-head pt-4">W-9 Form</p>
                            <p className="w0-form-subhead">You have filled w-9 form. <span><img alt="" src={green_tick} className="green-tick" /></span></p>

                            </div>
                            </div>
                            </div>
                </div>
        </div>

        

         );
    }
}
 
export default Ad_revenue;