
import Dashboard from './views/dashboard/dashboard'
import User_management from './views/user/usermanagement'
import Bonus_topic from './views/topic-management/bonus-topic'
import Adventure_topic from './views/topic-management/adventure-topic'
import Connection_topic from './views/topic-management/connection-topic'

import Pre_comments from './views/pre-comments/pre-comments'
import Add_comments from './views/pre-comments/add-comment'
import Referrals from './views/referrals/referrals'
import Influencer from './views/influencer/influencer'
import Celebrity from './views/celebrity/celebrity'
import Ad_revenue from './views/ad-revenue/ad-revenue'
import profile from './views/profile/profile'

import Add_topic from './views/topic-management/addtopic/addtopic'
import Add_connection_topic from './views/topic-management/addtopic/add-connection-topic'
import Add_topic_group from './views/topic-management/addtopic/addtopic-group'
import Add_group from './views/topic-management/addtopic/addgroup'




const routes = [
  { path: "/",exact: true,  name: "Dashboard", component: Dashboard},
  { path: "/user-management", name: "User-management", component: User_management },
  { path: "/bonus-topic", name: "Bonus_topic", component: Bonus_topic },
  { path: "/adventure-topic", name: "Adventure_topic", component: Adventure_topic },
  { path: "/connection-topic", name: "Connection_topic", component: Connection_topic },
  { path: "/add-topic", name: "Add_topic", component: Add_topic },
  { path: "/add-connection-topic", name: "Add_connection_topic", component: Add_connection_topic },
  { path: "/add-topic_groups", name: "Add_topic_group", component: Add_topic_group },
  { path: "/add-group", name: "Add_group", component: Add_group },
  { path: "/pre_comments", name: "Pre_comments", component: Pre_comments },
  { path: "/add_comment", name: "Add_comment", component: Add_comments },
  { path: "/referrals", name: "Referrals", component: Referrals },
  { path: "/influencer", name: "Influencer", component: Influencer },
  { path: "/celebrity", name: "Celebrity", component: Celebrity },
  { path: "/ad_revenue", name: "Ad_revenue", component: Ad_revenue },
  { path: "/settings", name: "profile", component: profile },
];
export default routes;